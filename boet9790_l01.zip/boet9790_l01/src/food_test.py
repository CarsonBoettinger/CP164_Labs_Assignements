"""
-------------------------------------------------------
Foods Test
-------------------------------------------------------
Author:  Carson Boettinger
ID:      210799790
Email:   boet9790@mylaurier.ca
__updated__ = "2024-01-13"
-------------------------------------------------------
"""
from Food import Food
from Food_utilities import write_foods,read_foods, read_food, get_food
#test 1
print(Food.origins())


#test 2

f = get_food()
print(f)


#test 3

f = read_food("Spanakopita|5|True|260")
print(f)


#test 4

file_name = "foods.txt"
fv = open(file_name,"r",encoding = "utf-8")
foods = read_foods(fv)


#test 5

fn = "foods.txt"
fv = open(fn,"w",encoding = "utf-8")

write_foods(fv, foods)

