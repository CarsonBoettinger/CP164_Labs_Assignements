"""
-------------------------------------------------------
Test File 2 
-------------------------------------------------------
Author:  Carson Boettinger
ID:      210799790
Email:   boet9790@mylaurier.ca
__updated__ = "2024-01-13"
-------------------------------------------------------
"""
from Food import Food
food = Food("Butter Chicken",2,True,490)
print(food)